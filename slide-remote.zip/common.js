/* Slide Remote — lógica compartida (visor del iPad y control del celular) */
(function (g) {
  'use strict';
  var DEFAULT_RELAY = 'https://ntfy.sh';

  function safeGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function safeSet(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }

  function rand(n) {
    var chars = 'abcdefghjkmnpqrstuvwxyz23456789', out = '', a = new Uint8Array(n);
    (g.crypto || g.msCrypto).getRandomValues(a);
    for (var i = 0; i < n; i++) out += chars[a[i] % chars.length];
    return out;
  }
  function cleanRoom(s) { return String(s || '').toLowerCase().replace(/[^a-z0-9-]/g, '').slice(0, 40); }

  function getRelayBase() {
    var q = new URLSearchParams(location.search).get('relay');
    if (q) safeSet('sr_relay', q.replace(/\/+$/, ''));
    return safeGet('sr_relay') || DEFAULT_RELAY;
  }
  function getRoom(preferred) {
    var r = cleanRoom(preferred) || cleanRoom(safeGet('sr_room'));
    if (!r) r = rand(10);
    safeSet('sr_room', r);
    return r;
  }
  function setRoom(r) { r = cleanRoom(r); if (r.length >= 6) safeSet('sr_room', r); return r; }

  // Posición = [slide, paso]. Los pasos son los "clics" de aparición de cada slide.
  function advance(deck, pos, dir) {
    var i = pos[0], k = pos[1];
    if (dir > 0) {
      if (k < deck[i].steps.length - 1) return [i, k + 1];
      if (i < deck.length - 1) return [i + 1, 0];
      return [i, k];
    }
    if (k > 0) return [i, k - 1];
    if (i > 0) return [i - 1, deck[i - 1].steps.length - 1];
    return [i, k];
  }
  function clampPos(deck, pos) {
    var i = Math.max(0, Math.min(deck.length - 1, pos[0] | 0));
    var k = Math.max(0, Math.min(deck[i].steps.length - 1, pos[1] | 0));
    return [i, k];
  }
  function samePos(a, b) { return a && b && a[0] === b[0] && a[1] === b[1]; }

  function Relay(room) {
    this.room = room;
    this.url = getRelayBase() + '/wpdeck-' + room;
    this.me = rand(8);
    this.seen = {};
    this.onMessage = function () {};
    this.onStatus = function () {};
    this.status = 'connecting';
  }
  Relay.prototype._set = function (s) { if (s !== this.status) { this.status = s; this.onStatus(s); } };
  Relay.prototype.connect = function () {
    var self = this;
    if (self.es) { try { self.es.close(); } catch (e) {} }
    var es = new EventSource(self.url + '/sse');
    self.es = es;
    es.addEventListener('open', function () { self._set('ok'); });
    es.onerror = function () { self._set('retry'); };
    es.onmessage = function (ev) {
      var m; try { m = JSON.parse(ev.data); } catch (e) { return; }
      if (!m || m.event !== 'message') return;
      if (m.id) { if (self.seen[m.id]) return; self.seen[m.id] = 1; }
      if (m.time && Math.abs(Date.now() / 1000 - m.time) > 30) return; // ignora mensajes viejos
      var body = null;
      try { body = JSON.parse(m.message); } catch (e) { body = null; }
      if (!body || typeof body !== 'object') body = { c: String(m.message || '').trim().toLowerCase() };
      if (body.f && body.f === self.me) return; // eco propio
      self.onMessage(body);
    };
  };
  Relay.prototype.send = function (msg) {
    var self = this;
    msg.f = self.me;
    return fetch(self.url, { method: 'POST', body: JSON.stringify(msg) })
      .then(function (r) { if (!r.ok) throw new Error('http ' + r.status); self._set('ok'); return true; })
      .catch(function () { self._set('error'); return false; });
  };

  function keepAwake() {
    var lock = null;
    function req() {
      if (!('wakeLock' in navigator)) return;
      navigator.wakeLock.request('screen').then(function (l) { lock = l; }).catch(function () {});
    }
    document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'visible') req(); });
    req();
  }

  function loadDeck() { return fetch('deck.json').then(function (r) { return r.json(); }).then(function (d) { return d.slides; }); }

  g.SR = { rand: rand, getRoom: getRoom, setRoom: setRoom, cleanRoom: cleanRoom, getRelayBase: getRelayBase,
           advance: advance, clampPos: clampPos, samePos: samePos, Relay: Relay, keepAwake: keepAwake, loadDeck: loadDeck };
})(window);

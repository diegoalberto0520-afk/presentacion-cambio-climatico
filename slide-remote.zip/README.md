# Slide Remote

Visor de presentación para el **iPad** + control remoto en el **celular** (con notas y temporizador) + atajos para el **Apple Watch**.
Inspirado en [WatchPointer](https://github.com/umarz317/WatchPointer), pero pensado para presentar desde un iPad, donde iOS no permite hacerse pasar por un mouse o teclado Bluetooth. Por eso aquí el iPad es una página web y el celular le manda órdenes por internet.

## Cómo funciona

```
iPhone (remote.html) ──┐
Apple Watch (Atajos) ──┼──►  relé gratuito ntfy.sh  ──►  iPad (index.html)
Teclado / clicker ─────┘            (solo "next", "prev"…)
```

- `index.html` es el visor del iPad. Muestra las diapositivas como imágenes y sigue los "clics" de aparición de las 5 slides con pasos.
- `remote.html` es el control del celular: botones grandes, miniatura, **notas del orador**, temporizador, pantalla negra e "Ir a…".
- Los mensajes viajan por [ntfy.sh](https://ntfy.sh) usando una **sala** con código aleatorio. No hay servidor propio ni cuentas.

## Publicarlo en tu GitHub (GitHub Pages)

1. Crea un repositorio nuevo (por ejemplo `slide-remote`).
2. Sube **todo el contenido de esta carpeta** (incluida `.nojekyll`, `slides/` y `thumbs/`).
3. En el repositorio: **Settings → Pages → Build and deployment → Deploy from a branch → `main` / `(root)` → Save**.
4. Al minuto tendrás una dirección tipo `https://TU-USUARIO.github.io/slide-remote/`.

> Ojo: en un repositorio público, las diapositivas quedan públicas en esa dirección.

## Usarlo el día de la exposición

1. **iPad:** abre la dirección en Safari. Para pantalla completa: Compartir → *Añadir a pantalla de inicio* y ábrelo desde ahí.
2. **iPhone:** escanea el código QR que aparece en el iPad con la cámara. Se abre el control con las notas.
3. En el iPad pulsa **Empezar presentación**.

Controles en el iPad: tocar derecha/izquierda, deslizar, flechas o clicker Bluetooth, **mantener el dedo = puntero láser**, `B` = pantalla negra, `F` = pantalla completa.

## Apple Watch con Atajos (sin programar)

La sala aparece en la pantalla inicial del iPad (ejemplo: `k3m9x2qa7b`).

1. En el iPhone abre **Atajos** y crea un atajo llamado **Siguiente** con la acción **Obtener contenido de URL**.
2. URL: `https://ntfy.sh/wpdeck-TU-SALA`
3. Método: **POST** · Cuerpo de la solicitud: **JSON** · añade un campo de texto `c` con valor `next`.
4. En los detalles del atajo activa **Mostrar en Apple Watch**.
5. Duplica el atajo con el nombre **Atrás** y valor `prev`.

La sala se queda guardada en el iPad, así que el atajo solo se configura una vez (a menos que pulses *Sala nueva*).

## Límites que debes conocer

- **Necesita internet** en el iPad y en el celular. Si falla, el iPad sigue funcionando solo con toques, flechas o clicker.
- ntfy.sh es gratuito y limita los mensajes por día. Cada avance gasta uno. Ensaya con calma y no abuses de las pruebas el mismo día de la exposición.
- Las diapositivas son **imágenes**: no hay videos ni las animaciones propias de PowerPoint. Solo se respetan los pasos por clic de las slides 6, 8, 11, 14 y 17.
- Cualquiera que conozca el código de sala puede pasar tus diapositivas: no lo compartas.
- Para usar tu propio servidor ntfy, abre el visor y el control con `?relay=https://tu-servidor` una vez.

## Actualizar las diapositivas

Si cambias el PowerPoint, hay que volver a exportar las imágenes de `slides/` y `thumbs/` y regenerar `deck.json`.
